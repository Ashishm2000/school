        </div>
        <footer class="page-footer font-small blue" style="position: fixed; bottom: 0px; background-color:#343a40; width:100%">
            <div class="footer-copyright text-center py-3" id="poweredBy" style="text-align:center;color:#ffffff;font-weight:bolder"></div>
        </footer>
        <script src="js/main.js"></script>
    </body>
</html>