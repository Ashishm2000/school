<?php $_SETTINGS = array (
  'Site Name' => 'Open School Library Lite',
  'Welcome Message' => 'Hello and welcome',
  'Home' => 'Home',
  'Borrow' => 'Borrow',
  'Return' => 'Return',
  'Edit Book' => 'Edit Book',
  'New Book' => 'New Book',
  'New User' => 'New User',
  'Check Update' => 'Check for Update',
  'Search' => 'Search',
  'Settings' => 'Settings'
); ?>